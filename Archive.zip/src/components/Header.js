import React, { Component } from 'react';

class Header extends Component {
  render() {
    return (
        <div className="jumbotron jumbotron-fluid text-center">
            <div className="container">
                <h1>Animorphic Studios</h1>
            </div>
        </div>
    );
  }
}

export default Header;
